class PlanetConstellation:
    pass