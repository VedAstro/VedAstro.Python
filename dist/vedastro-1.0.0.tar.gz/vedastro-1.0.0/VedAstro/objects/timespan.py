class TimeSpan:

    def __int__(self):
        pass