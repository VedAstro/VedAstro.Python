class PlanetToSignRelationship:
    pass