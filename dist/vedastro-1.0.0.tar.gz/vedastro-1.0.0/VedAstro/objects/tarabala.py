class Tarabala:
    pass