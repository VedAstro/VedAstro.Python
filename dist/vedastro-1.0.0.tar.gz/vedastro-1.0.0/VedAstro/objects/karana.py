class Karana:
    pass