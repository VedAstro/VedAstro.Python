class NithyaYoga:
    pass