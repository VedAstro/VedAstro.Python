class DayOfWeek:
    pass