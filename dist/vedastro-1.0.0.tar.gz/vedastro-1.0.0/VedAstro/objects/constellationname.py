class ConstellationName:
    pass