class DateTimeOffset():
# Todo:- create a custom class represnting c# datetimeoffset
    def __init__(self):
        pass