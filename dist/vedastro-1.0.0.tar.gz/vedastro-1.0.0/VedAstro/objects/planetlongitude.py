class PlanetLongitude:
    pass