class Angle:
    pass