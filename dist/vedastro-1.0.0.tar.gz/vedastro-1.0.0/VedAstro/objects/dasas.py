class Dasas:
    pass