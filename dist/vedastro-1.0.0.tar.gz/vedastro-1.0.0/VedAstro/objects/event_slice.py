class EventSlice:
    def __init__(self, name, nature, description, time, occurring):
        self.name = name
        self.nature = nature
        self.description = description
        self.time = time
        self.occurring = occurring