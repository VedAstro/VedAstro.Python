class ConstellationAnimal:
    pass