class House:
    pass