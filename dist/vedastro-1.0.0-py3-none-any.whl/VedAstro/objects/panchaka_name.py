class PanchakaName:
    pass