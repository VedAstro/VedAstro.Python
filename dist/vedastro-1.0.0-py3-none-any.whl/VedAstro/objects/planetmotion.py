class PlanetMotion:
    pass