class PlanetToPlanetRelationship:
    pass