class HouseSubStrength:
    pass