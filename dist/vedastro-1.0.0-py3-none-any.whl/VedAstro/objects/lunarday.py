class LunarDay:
    pass