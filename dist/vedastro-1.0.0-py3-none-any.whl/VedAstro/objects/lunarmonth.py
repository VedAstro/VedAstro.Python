class LunarMonth:
    pass