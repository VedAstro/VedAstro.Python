import VedAstro.Library as VedAstro

class Gender:
    Empty = VedAstro.Gender.Empty
    Male = VedAstro.Gender.Male
    Female = VedAstro.Gender.Female
