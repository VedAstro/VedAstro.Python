import VedAstro.Library as VedAstro


class EventNature:
    Empty = VedAstro.EventNature.Empty,
    Good = VedAstro.EventNature.Good,
    Neutral = VedAstro.EventNature.Neutral,
    Bad = VedAstro.EventNature.Bad
