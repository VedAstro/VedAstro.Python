class Event:
    pass